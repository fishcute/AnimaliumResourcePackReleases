#version 330
#moj_import <minecraft:globals.glsl>
#moj_import <util.glsl>

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor;
    if (color.rgb == vec3(239.0 / 255.0, 50.0 / 255.0, 61.0 / 255.0)) {
        fragColor = vec4(colors(gl_FragCoord.xy, ScreenSize, GameTime, 1), color.a);
    }
    else {
        if (color.a == 0.0) {
            discard;
        }
        fragColor = color * ColorModulator;
    }
}
