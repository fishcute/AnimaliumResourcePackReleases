#version 330

#moj_import <minecraft:globals.glsl>
#moj_import <util.glsl>

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

    if (vertexColor.r == (1.0 / 255.0) && vertexColor.g == (2.0 / 255.0) && vertexColor.b == (5.0 / 255.0)) {
        float borderSize = 0.01;
        float borderAlphaSize = 0.01;

        vec2 uv = gl_FragCoord.xy / ScreenSize;

        if ((((uv.x > 1.0 - (borderSize + borderAlphaSize)) &&
                    (uv.x < 1.0 - (borderAlphaSize)) &&
                    (uv.y > (borderSize + borderAlphaSize)) && (uv.y < (1.0 - (borderSize + borderAlphaSize)))) || 
                ((uv.x > (borderAlphaSize)) &&
                    (uv.x < (borderSize + borderAlphaSize)) &&
                    (uv.y > (borderSize + borderAlphaSize)) && (uv.y < (1.0 - (borderSize + borderAlphaSize)))) || 
                ((uv.y > 1.0 - (2.0 * (borderSize + borderAlphaSize))) &&
                    (uv.y < 1.0 - (2.0 * (borderAlphaSize))) &&
                    (uv.x > (borderSize + borderAlphaSize)) && (uv.x < (1.0 - (borderSize + borderAlphaSize)))) || 
                ((uv.y > (2.0 * (borderAlphaSize))) &&
                    (uv.y < (2.0 * (borderSize + borderAlphaSize)) &&
                        (uv.x > (borderSize + borderAlphaSize)) && (uv.x < (1.0 - (borderSize + borderAlphaSize)))))) &&
            (uv.x < 0.29 || uv.x > 0.71) &&

            (uv.x < (borderAlphaSize + borderSize) || uv.x > (borderAlphaSize + (2 * borderSize))) && 
            (uv.x > (1 - (borderAlphaSize + borderSize)) || uv.x < (1 - (borderAlphaSize + (2 * borderSize)))) &&

            (uv.y < (2 * (borderAlphaSize + borderSize)) || uv.y > (2 * (borderAlphaSize + (2 * borderSize)))) &&
            (uv.y > (1 - (2 * (borderAlphaSize + borderSize))) || uv.y < (1 - (2 * (borderAlphaSize + (2 * borderSize)))))) {
            fragColor = vec4(colors(gl_FragCoord.xy, ScreenSize, GameTime * 0.75, 1), 0.5);
        }
        else {
            discard;
        }
    }
    else if (vertexColor.r == (0.0 / 255.0) && vertexColor.g == (180.0 / 255.0) && vertexColor.b == (140.0 / 255.0)) {
        vec4 textColor = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
        if (textColor.a < 0.1) {
            discard;
        }
        color = vec4(colors(gl_FragCoord.xy, ScreenSize, GameTime * 0.5, 20), 1);
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
