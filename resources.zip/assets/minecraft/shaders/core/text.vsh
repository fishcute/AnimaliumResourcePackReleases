#version 330
#moj_import <minecraft:globals.glsl>

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

    if (Color.r == (1.0 / 255.0) && Color.g == (2.0 / 255.0) && Color.b == (3.0 / 255.0)) {
        vertexColor = vec4(1, 1, 1, 1);
        gl_Position = ProjMat * ModelViewMat * vec4(Position + vec3(-45, 15, 0), 1.0);
    }
    else if (Color.r == (1.0 / 255.0) && Color.g == (2.0 / 255.0) && Color.b == (4.0 / 255.0)) {
        vertexColor = vec4(1, 1, 1, 1);
        gl_Position = ProjMat * ModelViewMat * vec4(Position + vec3(0, 40 + sin(GameTime * 1000) * 3, 0), 1.0);
    }
    else if (Color.r == (1.0 / 255.0) && Color.g == (2.0 / 255.0) && Color.b == (5.0 / 255.0)) {
        vec2[] corners = vec2[4](
            vec2(-1,  1),
            vec2(-1, -1),
            vec2(1, -1),
            vec2(1,  1));

        gl_Position = vec4(corners[gl_VertexID % 4], 0, 0);
        vertexColor = Color;
    }
    else if (Color.r == (0.0 / 255.0) && Color.g == (180.0 / 255.0) && Color.b == (140.0 / 255.0)) {
        gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
        vertexColor = Color;
    }
}
