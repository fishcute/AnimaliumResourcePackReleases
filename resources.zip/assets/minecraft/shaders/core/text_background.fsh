#version 330

#moj_import <util.glsl>
#moj_import <minecraft:globals.glsl>

#ifndef IS_SEE_THROUGH
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>

#ifndef IS_SEE_THROUGH
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;

out vec4 fragColor;

void main() {
#ifdef IS_SEE_THROUGH
    vec4 color = vertexColor;
#else
    vec4 color = vertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);

    if (sphericalVertexDistance > 30) {
        float threshold = bayer16x16(int(gl_FragCoord.x), int(gl_FragCoord.y));
        float alpha = color.a;

        if (alpha < threshold) {
            discard;
        }
    }
#endif
}
