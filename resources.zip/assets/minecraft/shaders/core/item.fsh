#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:util.glsl>
#moj_import <minecraft:custom_stars.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;

flat in vec4 tintColor;

in vec3 vertexPosition;

out vec4 fragColor;

#define BLACK vec4(0.0,0.0,0.0,1.0)
const float FOG = 0.75;

void main() {
    vec4 color = texture(Sampler0, texCoord0);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif
	vec4 trueColor = texture(Sampler0, texCoord0);
    if (trueColor.a == 0.0 || trueColor.rgb == vec3(255.0 / 255.0, 0.0, 114.0 / 255.0) || trueColor.rgb == vec3(255.0 / 255.0, 0.0, 115.0 / 255.0) || trueColor.rgb == vec3(255.0 / 255.0, 0.0, 113.0 / 255.0)) {
        discard;
    }
    else if (trueColor.a == 254.0 / 255.0) {
        fragColor = trueColor;
    }
    else if (trueColor.r == (13.0 / 255.0) && trueColor.g == (123.0 / 255.0)) {
        discard;
    }
    // Star background
    else if (trueColor.rg == vec2(176, 91) / 255 || trueColor.rg == vec2(177, 91) / 255 || trueColor.rg == vec2(178, 91) / 255 || trueColor.rg == vec2(179, 91) / 255) {
        //vec2 coord = fract((texCoord0 * vec2(1.0, 0.5))*128);
        vec3 direction = normalize(vertexPosition);

        vec4 background = BLACK;
        int colorArrayID = 0;

        // if (trueColor.r == 178.0 / 255.0) {
        //     background = vec4(0, 0, 0, (sin(GameTime * 800) + 1) / 2);

        //     float s = (sin(GameTime * 1200) + 1) / 2;

        //     background += vec4(0.611764706 * s, 0.368627451 * s, 0.792156863 * s, 0);
        //     colorArrayID = 1;
        // }
        // else if (trueColor.r == 179.0 / 255.0) {
        //     background = vec4(0);
        //     colorArrayID = 2;

        //     trueColor.b = 1.0 / 255.0;
        // }

        fragColor = starTexture(direction, trueColor.b, background, colorArrayID);
        if (trueColor.r == 177.0 / 255.0) {
            float transparency = bezierBlend(clamp(0.5 - 4 * dot(direction, vec3(0, 1, 0)), 0, 1));
            fragColor = mix(fragColor, vec4(138, 249, 255, 255) / 255, transparency);
        }
    }
    // Special effects
    else if (trueColor.a == 252.0/255.0) {
        // Skyboxes only
        if (tintColor.r == 99.0 / 255.0) {
            float g = (mod(GameTime, 0.5) / 86);
            fragColor = texture(Sampler0, vec2(texCoord0.x, texCoord0.y + g));
        }
        // Particle emitters only
        else {
            vec4 c = texture(Sampler0, texCoord0) * tintColor;
            fragColor = vec4(c.rgb, 1);
        }
    } else if (trueColor.a == 253.0/255.0 || trueColor.a == 251.0/255.0) {
        fragColor = texture(Sampler0, texCoord0);
        if (fragColor.rgb == vec3(192, 0, 255) / 255) {
            discard;
        }
    } else if (trueColor.a == 250.0 / 255.0) {
        vec4 f = texture(Sampler0, texCoord0);
        fragColor = vec4(
            (1.0 - FOG) * f.x + FogColor.x * FOG,
            (1.0 - FOG) * f.y + FogColor.y * FOG,
            (1.0 - FOG) * f.z + FogColor.z * FOG,
            1);
    }
    else if (trueColor.a == 164.0 / 255.0 || trueColor.a == 165.0 / 255.0 || trueColor.a == 70.0 / 255.0) {
        if (tintColor.r == 99.0 / 255.0) {
            fragColor = texture(Sampler0, texCoord0);
        }
        else {
            fragColor = texture(Sampler0, texCoord0) * tintColor;
        }
    }
	else {
		color *= vertexColor * ColorModulator;
		color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
		color *= lightMapColor;

		fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
	}
}
