#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform mat3 IViewRotMat;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;

out vec3 vertexPosition;
out vec2 texCoord0;
flat out vec4 tintColor;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    tintColor = Color;
	
    vertexPosition = Position;

    texCoord0 = UV0;
	
	// Additions
    if (Color.r == 99.0 / 255.0) {
        float layer = 0;
        float spin = 0;

        layer = Color.g;

        if (Color.g == 255.0 / 255.0) {
            // Special Star 1
            layer = 0.02;
        }
        else if (Color.g == 254.0 / 255.0) {
            // Special Star 2
            layer = 0.03;
        }
        else if (Color.g == 253.0 / 255.0) {
            // Special Star 3
            layer = 0.04;
        }
        else {
            // Normal sky
            spin = Color.b * 255;
        }

        if (spin == 0) {
            if (layer != 1) {
                gl_Position = vec4(gl_Position.xy, (0.01 - (0.001 * layer)), gl_Position.w);
            }

        }
        else {
            gl_Position = vec4(IViewRotMat * Position, 1.0);

            float w = GameTime * 20;
            w *= (spin - 128) / 64;

            gl_Position = vec4(IViewRotMat * Position, 1.0);

            gl_Position = vec4(gl_Position.x * cos(w) - gl_Position.z * sin(w), gl_Position.y, gl_Position.z * cos(w) + gl_Position.x * sin(w), gl_Position.w);

            gl_Position += vec4(0, sin(w * 15) * 13, 0, 0);

            gl_Position.xyz = inverse(IViewRotMat) * gl_Position.xyz;

            gl_Position = ProjMat * ModelViewMat * gl_Position;

            if (layer != 1) {
                gl_Position = vec4(gl_Position.xy, (0.01 - (0.001 * layer)), gl_Position.w);
            }
        }
        sphericalVertexDistance = 0;
        cylindricalVertexDistance = 0;
        lightMapColor = vec4(1, 1, 1, 1);
        vertexColor = vec4(1, 1, 1, 1);
    }
}
