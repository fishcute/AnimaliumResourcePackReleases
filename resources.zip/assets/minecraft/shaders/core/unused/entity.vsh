#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

#moj_import <cem_user/detection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;

#ifndef NO_OVERLAY
uniform sampler2D Sampler1;
#endif

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
out vec4 vertexPerFaceColorBack;
out vec4 vertexPerFaceColorFront;
#else
out vec4 vertexColor;
#endif

#ifndef EMISSIVE
out vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
out vec4 overlayColor;
#endif

out vec2 texCoord0;

// CEM
out vec4 cem_pos1, cem_pos2, cem_pos3, cem_pos4;
out vec3 cem_glPos;
out vec3 cem_uv1, cem_uv2;
out vec4 cem_lightMapColor;
flat out int cem;
flat out int cem_reverse;
flat out vec4 cem_light;

flat out vec4 debugColor;

bool around(vec2 uv, int goalX, int goalY) {
    return (abs((uv.x * 255) - goalX) <= 0.5) && (abs((uv.y * 255) - goalY) <= 0.5);
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    // CEM setup
    const vec2[4] corners = vec2[4](vec2(0), vec2(0, 1), vec2(1, 1), vec2(1, 0));
    const vec2[4] corners2 = vec2[4](vec2(0), vec2(1, 0), vec2(1, 1), vec2(0, 1));
    vec2 corner = corners[gl_VertexID % 4];

    vec2 texSize = textureSize(Sampler0, 0);
    vec2 uv = floor(UV0 * texSize);

    cem_pos1 = cem_pos2 = cem_pos3 = cem_pos4 = vec4(0);
    cem_uv1 = cem_uv2 = vec3(0);
    cem = cem_reverse = 0;
    float cem_size = 1;

    vec4 testColor = texelFetch(Sampler0, ivec2(63, 0), 0);
    vec2 armorUV = floor(UV0 * vec2(64, 32));

    vec4 armorTestColorIn = texelFetch(Sampler0, ivec2(uv - corners[(gl_VertexID + 3) % 4]), 0);
    vec4 armorTestColor = texelFetch(Sampler0, ivec2(armorUV - (1 - corner.yx) + vec2(0, 64)), 0);

    vec4 cemVertexColor = vec4(1);

    bool correctVertex = around(UV0, 112, 128) || around(UV0, 143, 159);
    ivec2 results = detection(texelFetch(Sampler0, ivec2(63, 0), 0), correctVertex);

    cem = results.x;
    cem_size = results.y;

    // CEM detection
    if (cem != 0) {
        vec4 modelPos = vec4(Position, 1.0);
        modelPos.xyz += vec3(ProjMat[3].xy / vec2(ProjMat[0][0], ProjMat[1][1]), 0) * mat3(ModelViewMat);

        vec2 cornerT = corner * 2 - 1;
        if (ProjMat[3][0] == -1)
            cornerT = cornerT.yx * 32;

        vec4 cem_Pos = ModelViewMat * modelPos + vec4(cornerT * 2 * cem_size, 0, 0);

        modelPos.w = 1;

        #ifdef TRIDENT
        if (ProjMat[3][0] == -1) {
            modelPos *= (sin(GameTime * 1000) + 1) * 1000;
        }
        #endif

        switch (gl_VertexID % 4) {
            case 0:
                cem_pos1 = modelPos;
                cem_uv1 = vec3(uv, 1);
                break;
            case 1:
                cem_pos2 = modelPos;
                break;
            case 2:
                cem_pos3 = modelPos;
                cem_uv2 = vec3(uv, 1);
                break;
            case 3:
                cem_pos4 = modelPos;
                break;
        }

        cem_Pos.z = min(cem_Pos.z, -1);
        cem_glPos = cem_Pos.xyz;
        //cem_Pos -= ProjMat[3] / cem_Pos.z;
        mat4 proj = ProjMat;
        proj[3].xy = vec2(0, 0);
        gl_Position = proj * cem_Pos;

        cemVertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, vec4(1));
        cem_lightMapColor = texelFetch(Sampler2, UV2 / 16, 0);
    }

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    if (cem != 0) {
        vertexColor = cemVertexColor;
    }
    else {
        vertexColor = Color;
    }
#else
    if (cem != 0) {
        vertexColor = cemVertexColor;
    }
    else {
        vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    }
#endif

#ifndef EMISSIVE
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif

#ifndef NO_OVERLAY
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;

#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
}
