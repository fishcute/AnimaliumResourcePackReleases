#version 150
#moj_import <minecraft:util.glsl>
#moj_import <minecraft:globals.glsl>

// Star Variables

#define CELL_SIZE 0.0125
#define PI 3.1415926538
#define NUM_COLORS 13
#define STAR_SIZE 0.1
#define STAR_SIZE_VARIANCE 0.0005
#define BRIGHTNESS_CURVE 12.0

#define CYL_CELL_RADIALS 256
#define CYL_CELL_LENGTH 1
#define DENSITY_FACTOR 0.99

#define ATTENUATION_FACTOR 0.3
#define DISTANT_DENSITY_FACTOR 0.75

// Star Colors 1

const vec3[NUM_COLORS] COLORS_1 = vec3[NUM_COLORS](
    vec3(1.00000, 0.76602, 0.57357),
    vec3(1.00000, 0.89417, 0.80757),
    vec3(1.00000, 0.89417, 0.80757),
    vec3(1.00000, 0.96529, 0.92878),
    vec3(1.00000, 0.96529, 0.92878),
    vec3(1.00000, 0.96529, 0.92878),
    vec3(1.00000, 0.96529, 0.92878),
    vec3(1.00000, 0.96529, 0.92878),
    vec3(1.00000, 0.96529, 0.92878),
    vec3(0.79100, 0.85518, 1.00000),
    vec3(0.79100, 0.85518, 1.00000),
    vec3(0.79100, 0.85518, 1.00000),
    vec3(0.72123, 0.81157, 1.00000));

// Star Colors 2

const vec3[NUM_COLORS] COLORS_2 = vec3[NUM_COLORS](
    vec3(1.00000, 0.60000, 0.95294),
    vec3(1.00000, 0.60000, 0.95294),
    vec3(1.00000, 0.60000, 0.95294),
    vec3(1.00000, 0.60000, 0.95294),
    vec3(0.49019, 0.29019, 0.67450),
    vec3(0.49019, 0.29019, 0.67450),
    vec3(0.49019, 0.29019, 0.67450),
    vec3(0.49019, 0.29019, 0.67450),
    vec3(0.92941, 0.84313, 0.95294),
    vec3(0.92941, 0.84313, 0.95294),
    vec3(0.92941, 0.84313, 0.95294),
    vec3(0.92941, 0.84313, 0.95294),
    vec3(0.92941, 0.84313, 0.95294));

// Star Colors 3

const vec3[NUM_COLORS] COLORS_3 = vec3[NUM_COLORS](
    vec3(0, 0.99608, 0.99608),
    vec3(0, 0.99608, 0.99608),
    vec3(0, 0.99608, 0.99608),
    vec3(0, 0.99608, 0.99608),
    vec3(0, 0.99608, 0.99608),
    vec3(0, 0.99608, 0.99608),
    vec3(0, 0.99608, 0.99608),
    vec3(0, 0.99608, 0.99608),
    vec3(0, 0.99608, 0.99608),
    vec3(0, 0.99608, 0.99608),
    vec3(0, 0.99608, 0.99608),
    vec3(0, 0.99608, 0.99608),
    vec3(0, 0.99608, 0.99608));

vec4 randColor(int colorArrayID) {
    if (colorArrayID == 2) {
        // Third
        return vec4(COLORS_3[int(mod(rand() * NUM_COLORS, NUM_COLORS))], rand());
    }
    if (colorArrayID == 1) {
        // Second
        return vec4(COLORS_2[int(mod(rand() * NUM_COLORS, NUM_COLORS))], rand());
    }
    else {
        return vec4(COLORS_1[int(mod(rand() * NUM_COLORS, NUM_COLORS))], rand());
    }
}

vec2 cylinderProject(vec3 direction, float radius) {
    return vec2(
        direction.x * radius / length(direction.yz),
        atan(direction.z, direction.y));
}

vec2 sphereProject(vec3 direction) {
    return vec2(
        atan(direction.z, direction.x),
        atan(direction.y / length(direction.xz)));
}

#define STATIONARY_SCALE 4

vec4 simpleStar(vec3 direction, float radius, float speed, vec4 background, int colorArrayID) {
    float yzLen = length(direction.yz);

    vec2 pos = vec2(direction.x * radius / yzLen, atan(direction.z, direction.y));
    float dist = length(vec2(pos.x, radius));
    if (speed == 0) {
        pos = sphereProject(direction);
        dist = radius;
    }
    if (speed != 0) {
        pos.x += GameTime * 25000 * speed + 2320.2425 * radius;
    }
    vec2 cell_id = pos * vec2(1.0, CYL_CELL_RADIALS/PI/2*radius);
    if (speed == 0) {
        cell_id = pos * vec2(CYL_CELL_RADIALS/PI/2*radius) * STATIONARY_SCALE;
        cell_id.x *= cos(floor(cell_id.y) / radius / CYL_CELL_RADIALS * 2 * PI / STATIONARY_SCALE);
    }
    if (speed == 0) {
        cell_id += vec2(31, 0) * radius * radius;
    }

    genSeed(vec2(radius, floor(cell_id.y)));

    cell_id.x += rand() * 1000;
    vec2 local_pos = fract(cell_id);
    cell_id = floor(cell_id);

    genSeed(cell_id.yx);

    float scale = (speed == 0) ? 0.075 : 1.0;

    float densityExponent = (speed == 0) ? 1.0 : pow(radius * DISTANT_DENSITY_FACTOR, 1.0 - speed);

    if (rand() > pow(1 - (1 - DENSITY_FACTOR) * scale, densityExponent)) {
        if (speed == 0 || local_pos.x < (2 * PI / CYL_CELL_RADIALS / CYL_CELL_LENGTH) / yzLen + (max(speed - 0.25, 0) * 1.33333333)) {
            float alpha = clamp(pow(1 - abs(dist / 20), 1.0/3.0), 0, 1);
            return mix(background, vec4(pow(randColor(colorArrayID).rgb, vec3(0.75)), 1.0), alpha);
        }
    }
    return background;
}

#define LAYERS 12
const float[LAYERS] radii = float[LAYERS](
    0.5,
    1.0,
    1.5,
    2.0,
    3.0,
    5.0,
    7.5,
    10.0,
    15.0,
    25.0,
    35.0,
    45.0);

vec4 starTexture(vec3 direction, float speed, vec4 background, int colorArrayID) {
    vec4 color = background;
    for (int i=0; i<LAYERS; i+=1) {
        color = simpleStar(direction, radii[i], speed, background, colorArrayID);
        if (color != background) {
            break;
        }
    }
    return color;
}

vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0/3.0, 1.0/3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

vec3 interpolateColor(float t) {
    t = clamp(t, 0.0, 1.0);
    float hue = mod(0.95 - t * 0.95, 1.0);
    return hsv2rgb(vec3(hue, 1.0, 1.0));
}
