ivec2 detection(vec4 identifier, bool correctVertex) {
    int cem = 0;
    int cemSize = 0;
    // Jetpack Model
    if (identifier == vec4(0, 0, 1, 255)) {
        if (correctVertex) {
            cem = 1;
            cemSize = 2;
        }
    }
    // Machine Gun Jetpack Model
    if (identifier == vec4(0, 0, 2, 255)) {
        if (correctVertex) {
            cem = 2;
            cemSize = 2;
        }
    }
    return ivec2(cem, cemSize);
}
