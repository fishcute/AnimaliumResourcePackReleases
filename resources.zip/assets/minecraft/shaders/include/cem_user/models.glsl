case 2: {
    // Jetpack Model
    vec4 NO_FACE = vec4(0, 0, 0, 0);
    SETUP();

    // Main body
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(0, 19, -8),
        /*Scale*/ vec3(6, 8, 2),
        /*Rotation*/ rotate(0, 0, 0),
        /*Pivot*/ vec3(0, 0, 0),
        /* UV */
        /*UV Down*/ vec4(30, 2, -6, 2),
        /*UV Up*/ vec4(30, 2, -6, -2),
        /*UV North*/ vec4(46, 0, 6, 8),
        /*UV East*/ vec4(14, 0, -2, 8),
        /*UV South*/ vec4(14, 0, 6, 8),
        /*UV West*/ vec4(12, 0, 2, 8));

    // Right shoulder
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(-7.265, 23.05, -2),
        /*Scale*/ vec3(2.55, 5, 10),
        /*Rotation*/ rotate(0, 0, 0),
        /*Pivot*/ vec3(0, 0, 0),
        /* UV */
        /*UV Down*/ vec4(46, 10, -2, -10),
        /*UV Up*/ vec4(12, 10, -2, -10),
        /*UV North*/ vec4(34, 0, 2, 5),
        /*UV East*/ vec4(10, 0, -10, 5),
        /*UV South*/ vec4(36, 0, 2, 5),
        /*UV West*/ vec4(0, 0, 10, 5));

    // Right top gun
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(-5.3, 26, -11),
        /*Scale*/ vec3(4, 5, 4),
        /*Rotation*/ rotate(0, 22.5, 0),
        /*Pivot*/ vec3(-4.2, 29.5, 5.4),
        /* UV */
        /*UV Down*/ vec4(12, 10, -4, 4),
        /*UV Up*/ vec4(8, 14, -4, -4),
        /*UV North*/ vec4(4, 14, 4, 5),
        /*UV East*/ vec4(0, 14, 4, 5),
        /*UV South*/ vec4(12, 14, 4, 5),
        /*UV West*/ vec4(8, 14, 4, 5));

    // Right bottom gun
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(-5.3, 13, -11),
        /*Scale*/ vec3(3, 8, 3),
        /*Rotation*/ rotate(0, 22.5, 0),
        /*Pivot*/ vec3(-4.2, 29.5, 5.4),
        /* UV */
        /*UV Down*/ vec4(9, 19, -3, 3),
        /*UV Up*/ vec4(6, 22, -3, -3),
        /*UV North*/ vec4(3, 22, 3, 8),
        /*UV East*/ vec4(0, 22, 3, 8),
        /*UV South*/ vec4(9, 22, 3, 8),
        /*UV West*/ vec4(6, 22, 3, 8));

    // Left shoulder
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(7.265, 23.05, -2),
        /*Scale*/ vec3(2.55, 5, 10),
        /*Rotation*/ rotate(0, 0, 0),
        /*Pivot*/ vec3(0, 0, 0),
        /* UV */
        /*UV Down*/ vec4(44, 10, 2, -10),
        /*UV Up*/ vec4(10, 10, 2, -10),
        /*UV North*/ vec4(36, 0, -2, 5),
        /*UV East*/ vec4(10, 0, -10, 5),
        /*UV South*/ vec4(38, 0, -2, 5),
        /*UV West*/ vec4(0, 0, 10, 5));

    // Left top gun
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(5.3, 26, -11),
        /*Scale*/ vec3(4, 5, 4),
        /*Rotation*/ rotate(0, -22.5, 0),
        /*Pivot*/ vec3(4.2, 29.5, 5.4),
        /*UV Down*/ vec4(8, 10, 4, 4),
        /*UV Up*/ vec4(4, 14, 4, -4),
        /*UV North*/ vec4(8, 14, -4, 5),
        /*UV East*/ vec4(12, 14, -4, 5),
        /*UV South*/ vec4(16, 14, -4, 5),
        /*UV West*/ vec4(4, 14, -4, 5));

    // Left bottom gun
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(5.3, 13, -11),
        /*Scale*/ vec3(3, 8, 3),
        /*Rotation*/ rotate(0, -22.5, 0),
        /*Pivot*/ vec3(4.2, 29.5, 5.4),
        /*UV Down*/ vec4(6, 19, 3, 3),
        /*UV Up*/ vec4(3, 22, 3, -3),
        /*UV North*/ vec4(6, 22, -3, 8),
        /*UV East*/ vec4(9, 22, -3, 8),
        /*UV South*/ vec4(12, 22, -3, 8),
        /*UV West*/ vec4(3, 22, -3, 8));
    break;
}
case 1: {
    // Jetpack Model
    vec4 NO_FACE = vec4(0, 0, 0, 0);
    SETUP();

    // Main body
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(0, 19, -8),
        /*Scale*/ vec3(6, 8, 2),
        /*Rotation*/ rotate(0, 0, 0),
        /*Pivot*/ vec3(0, 0, 0),
        /* UV */
        /*UV Down*/ vec4(30, 2, -6, 2),
        /*UV Up*/ vec4(30, 2, -6, -2),
        /*UV North*/ vec4(46, 0, 6, 8),
        /*UV East*/ vec4(14, 0, -2, 8),
        /*UV South*/ vec4(14, 0, 6, 8),
        /*UV West*/ vec4(12, 0, 2, 8));

    // Right shoulder
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(-7.265, 23.05, -2),
        /*Scale*/ vec3(2.55, 5, 10),
        /*Rotation*/ rotate(0, 0, 0),
        /*Pivot*/ vec3(0, 0, 0),
        /* UV */
        /*UV Down*/ vec4(46, 10, -2, -10),
        /*UV Up*/ vec4(12, 10, -2, -10),
        /*UV North*/ vec4(34, 0, 2, 5),
        /*UV East*/ vec4(10, 0, -10, 5),
        /*UV South*/ vec4(36, 0, 2, 5),
        /*UV West*/ vec4(0, 0, 10, 5));

    // Left shoulder
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(7.265, 23.05, -2),
        /*Scale*/ vec3(2.55, 5, 10),
        /*Rotation*/ rotate(0, 0, 0),
        /*Pivot*/ vec3(0, 0, 0),
        /* UV */
        /*UV Down*/ vec4(44, 10, 2, -10),
        /*UV Up*/ vec4(10, 10, 2, -10),
        /*UV North*/ vec4(36, 0, -2, 5),
        /*UV East*/ vec4(10, 0, -10, 5),
        /*UV South*/ vec4(38, 0, -2, 5),
        /*UV West*/ vec4(0, 0, 10, 5));

    // Pipe right
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(2.15, 11.8, -2.8),
        /*Scale*/ vec3(1, 12, 1),
        /*Rotation*/ rotate(10, -10, -57.5),
        /*Pivot*/ vec3(-3, 22.5, 0),
        /*UV Down*/ vec4(23, 7, -1, 1),
        /*UV Up*/ NO_FACE,
        /*UV North*/ vec4(24, 4, 1, 12),
        /*UV East*/ vec4(31, 0, 1, 12),
        /*UV South*/ vec4(32, 0, 1, 12),
        /*UV West*/ vec4(33, 0, 1, 12));

    // Thruster right
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(6.2, 10.775, -2.4),
        /*Scale*/ vec3(2, 7, 2),
        /*Rotation*/ rotate(10, -10, -57.5),
        /*Pivot*/ vec3(-3, 22.5, 0),
        /*UV Down*/ vec4(27, 10, -2, 2),
        /*UV Up*/ NO_FACE,
        /*UV North*/ vec4(22, 0, 2, 7),
        /*UV East*/ vec4(42, 0, 2, 7),
        /*UV South*/ vec4(38, 0, 2, 7),
        /*UV West*/ vec4(40, 0, 2, 7));

    // Big Thruster right
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(0.15, 8.65, 0.7),
        /*Scale*/ vec3(3, 6, 3),
        /*Rotation*/ rotate(30, 5, -17.5),
        /*Pivot*/ vec3(-3, 22.5, 0),
        /*UV Down*/ vec4(28, 7, -3, 3),
        /*UV Up*/ vec4(28, 7, -3, -3),
        /*UV North*/ vec4(55, 0, 3, 6),
        /*UV East*/ vec4(52, 0, 3, 6),
        /*UV South*/ vec4(0, 5, 3, 6),
        /*UV West*/ vec4(3, 5, 3, 6));

    // Pipe left
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(-2.15, 11.8, -2.8),
        /*Scale*/ vec3(1, 12, 1),
        /*Rotation*/ rotate(10, 10, 57.5),
        /*Pivot*/ vec3(3, 22.5, 0),
        /*UV Down*/ vec4(23, 7, -1, 1),
        /*UV Up*/ NO_FACE,
        /*UV North*/ vec4(24, 4, 1, 12),
        /*UV East*/ vec4(31, 0, 1, 12),
        /*UV South*/ vec4(32, 0, 1, 12),
        /*UV West*/ vec4(33, 0, 1, 12));

    // Thruster Left
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(-6.2, 10.775, -2.4),
        /*Scale*/ vec3(2, 7, 2),
        /*Rotation*/ rotate(10, 10, 57.5),
        /*Pivot*/ vec3(3, 22.5, 0),
        /*UV Down*/ vec4(25, 10, 2, 2),
        /*UV Up*/ NO_FACE,
        /*UV North*/ vec4(24, 0, -2, 7),
        /*UV East*/ vec4(42, 0, -2, 7),
        /*UV South*/ vec4(40, 0, -2, 7),
        /*UV West*/ vec4(44, 0, -2, 7));

    // Big Thruster left
    ADD_BOX_ROTATE(
        /*Pos*/ vec3(-0.15, 8.65, 0.7),
        /*Scale*/ vec3(3, 6, 3),
        /*Rotation*/ rotate(30, -5, 17.5),
        /*Pivot*/ vec3(3, 22.5, 0),
        /*UV Down*/ vec4(25, 7, 3, 3),
        /*UV Up*/ vec4(25, 7, 3, -3),
        /*UV North*/ vec4(58, 0, -3, 6),
        /*UV East*/ vec4(6, 5, -3, 6),
        /*UV South*/ vec4(3, 5, -3, 6),
        /*UV West*/ vec4(55, 0, -3, 6));
}
break;