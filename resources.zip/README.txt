Hello, it seems like you've opened this resource pack. You can look, but do be aware of the following:
- You will see spoilers for future content. Look at your own loss.
- Content in this resource pack cannot be shared privately/publicly. You will be punished if you are found to be doing so.
- Do not spoil anything for other people, there are some people who want to enjoy the story as it goes.

This is not a license, so this is not stating what you may/may not do with the contents in this resource pack. 

However, if you are found to be using resources from this resource pack for other purposes without permission, we hold the right to punish you on our server.
If you are curious about using various assets, or how something works, feel free to create a support ticket and tag @fishcute (you will not be punished for asking).

Please reconsider looking further.
- Animalium